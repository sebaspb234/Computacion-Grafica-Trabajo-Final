#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>
#include "solve.h"
#include "random.h"

#include <filesystem>
#include <iostream>

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

#include <Shader.h>
#include <utility>
#include <vector>
#include <unordered_map>
#include <string>

#include <chrono>
#include <thread>
using namespace std;

//std::string rutaImagen="";
//rutaImagen = "C://texture//allspark.jpg";
//// CUBO

// INTEGRANTES: 
// Sebastian Andre Paz Ballón
// Joey Patrick Flores Dávila

template<class T>
class Point {
public:
	T x, y, z, c1, c2, c3, t1,t2;
	Point(T _x = 0, T _y = 0, T _z = 0, glm::vec3 color=glm::vec3(0.0f,0.0f,0.0f), T _t1=0, T _t2=3) {
		x = _x;
		y = _y;
		z = _z;
		c1 = color.x;
		c2 = color.y;
		c3 = color.z;
		t1 = _t1;
		t2 = _t2;
	}
};

class Cubito {
public:
	vector<Point<float>> vertices;
	float dim;
	unsigned int VAO, VBO;
	glm::vec3 center;
	
	const char* title_texture;
	unsigned int texture;
	//glm::mat4 model;
	float acc = 1.0f;
	glm::mat4 prevRot=glm::mat4(1.0f);

	Cubito(float _dim,glm::vec3 _pos,vector<glm::vec3> color) {			//Depende del tipo hacemos push a sus vertices
		title_texture = "allspark.jpg";
		dim = _dim;
		center = _pos;
		//FRONT
		vertices.push_back(Point<float>(-dim, -dim, dim,  color[0], 0.0f, 0.0f));
		vertices.push_back(Point<float>(dim, -dim, dim,   color[0], 1.0f, 0.0f));
		vertices.push_back(Point<float>(dim, dim, dim,    color[0], 1.0f, 1.0f));
		vertices.push_back(Point<float>(dim, dim, dim,    color[0], 1.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, dim, dim,   color[0], 0.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, -dim, dim,  color[0], 0.0f, 0.0f));
		//UP
		vertices.push_back(Point<float>(-dim, dim, -dim,  color[1], 0.0f, 1.0f));
		vertices.push_back(Point<float>(dim, dim, -dim,   color[1], 1.0f, 1.0f));
		vertices.push_back(Point<float>(dim, dim, dim,    color[1], 1.0f, 0.0f));
		vertices.push_back(Point<float>(dim, dim, dim,    color[1], 1.0f, 0.0f));
		vertices.push_back(Point<float>(-dim, dim, dim,   color[1], 0.0f, 0.0f));
		vertices.push_back(Point<float>(-dim, dim, -dim,  color[1], 0.0f, 1.0f));
		//LEFT
		vertices.push_back(Point<float>(-dim, dim, dim,   color[2], 1.0f, 0.0f));
		vertices.push_back(Point<float>(-dim, dim, -dim,  color[2], 1.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, -dim, -dim, color[2], 0.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, -dim, -dim, color[2], 0.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, -dim, dim,  color[2], 0.0f, 0.0f));
		vertices.push_back(Point<float>(-dim, dim, dim,   color[2], 1.0f, 0.0f));
		//DOWN
		vertices.push_back(Point<float>(-dim, -dim, -dim, color[3], 0.0f, 1.0f));
		vertices.push_back(Point<float>(dim, -dim, -dim,  color[3], 1.0f, 1.0f));
		vertices.push_back(Point<float>(dim, -dim, dim,   color[3], 1.0f, 0.0f));
		vertices.push_back(Point<float>(dim, -dim, dim,   color[3], 1.0f, 0.0f));
		vertices.push_back(Point<float>(-dim, -dim, dim,  color[3], 0.0f, 0.0f));
		vertices.push_back(Point<float>(-dim, -dim, -dim, color[3], 0.0f, 1.0f));
		//RIGHT
		vertices.push_back(Point<float>(dim, dim, dim,    color[4], 1.0f, 0.0f));
		vertices.push_back(Point<float>(dim, dim, -dim,   color[4], 1.0f, 1.0f));
		vertices.push_back(Point<float>(dim, -dim, -dim,  color[4], 0.0f, 1.0f));
		vertices.push_back(Point<float>(dim, -dim, -dim,  color[4], 0.0f, 1.0f));
		vertices.push_back(Point<float>(dim, -dim, dim,   color[4], 0.0f, 0.0f));
		vertices.push_back(Point<float>(dim, dim, dim,    color[4], 1.0f, 0.0f));
		//BACK
		vertices.push_back(Point<float>(-dim, -dim, -dim, color[5], 0.0f, 0.0f));
		vertices.push_back(Point<float>(dim, -dim, -dim,  color[5], 1.0f, 0.0f));
		vertices.push_back(Point<float>(dim, dim, -dim,   color[5], 1.0f, 1.0f));
		vertices.push_back(Point<float>(dim, dim, -dim,   color[5], 1.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, dim, -dim,  color[5], 0.0f, 1.0f));
		vertices.push_back(Point<float>(-dim, -dim, -dim, color[5], 0.0f, 0.0f));

	}
	void genBuffers();
	void load_create_texture(Shader*);
	void draw(Shader*,glm::vec3);
	void move(glm::vec3,Shader*,float);
	void trans(glm::vec3,Shader*);
	void deleteBuffers();
	
private:
	void updateBuffers();
	void move_vertices(glm::vec3,float);
	void trans_vertices(glm::vec3);
};

class Rubik {
	GLFWwindow* window;
	Shader* shader;
	vector<Cubito> cubitos;
	float dim;
	unordered_map<char, vector<int>>  parts;
	unordered_map<char, vector<int>>  levels; // partes de lluvia, niveles

public:
	bool drawing = true;
	vector<string> shuffle;
	vector<string> solution;
	float degrees;
	Rubik(GLFWwindow* _window, Shader* _shader, float _dim = 0.2f) {
		window = _window;
		shader = _shader;
		dim = _dim;
		degrees = -1.0f;
		float pos=dim*2+(dim/4);	//Positivo
		float neg=-1*(pos);		//Negativo
		glm::vec3 cubePositions[] = {
			glm::vec3(neg,  pos, pos),				//0Parte frontal
			glm::vec3(0.0f, pos, pos),				//1
			glm::vec3(pos,  pos, pos),				//2
			glm::vec3(neg,  0.0f,pos),				//3
			glm::vec3(0.0f,  0.0f, pos),			//4
			glm::vec3(pos,  0.0f,pos),				//5
			glm::vec3(neg,  neg, pos),				//6
			glm::vec3(0.0f, neg, pos),				//7
			glm::vec3(pos,  neg, pos),				//8

			glm::vec3(neg,  pos, 0.0f),				//9
			glm::vec3(0.0f, pos, 0.0f),				//10
			glm::vec3(pos,  pos, 0.0f),				//11
			glm::vec3(neg,  0.0f, 0.0f),			//12
			glm::vec3(pos,  0.0f, 0.0f),			//13
			glm::vec3(neg,  neg, 0.0f),				//14
			glm::vec3(0.0f, neg, 0.0f),				//15
			glm::vec3(pos,  neg, 0.0f),				//16


			glm::vec3(neg,  pos, neg),				//17
			glm::vec3(0.0f, pos, neg),				//18Parte trasera
			glm::vec3(pos,  pos, neg),				//19
			glm::vec3(neg,  0.0f,neg),				//20
			glm::vec3(0.0f, 0.0f,neg),				//21
			glm::vec3(pos,  0.0f,neg),				//22
			glm::vec3(neg,  neg, neg),				//23
			glm::vec3(0.0f, neg, neg),				//24
			glm::vec3(pos,  neg, neg)				//25
		};

		
		glm::vec3 colors[] = {
			glm::vec3(0.0f,0.0f,0.0f),			//Negro
			glm::vec3(1.0f,1.0f,1.0f),			//Blanco
			glm::vec3(1.0f,0.5f,0.0f),			//Naranja  
			//glm::vec3(0.8f,0.15f,1.0f),			//Morado  
			glm::vec3(1.0f,1.0f,0.0f),				//Amarillo
			glm::vec3(1.0f,0.025f,0.25f),			//Rojo
			glm::vec3(0.224f,1.0f,0.078f),			//Verde 
			glm::vec3(0.15f,0.35f,1.0f)			//Azul
		};
		int assignColor[][6] = {
			{4,1,5,0,0,0},	//Frontal
			{4,1,0,0,0,0},
			{4,1,0,0,6,0},
			{4,0,5,0,0,0},
			{4,0,0,0,0,0},
			{4,0,0,0,6,0},
			{4,0,5,3,0,0},
			{4,0,0,3,0,0},
			{4,0,0,3,6,0},	
			{0,1,5,0,0,0},	//Medio
			{0,1,0,0,0,0},
			{0,1,0,0,6,0},
			{0,0,5,0,0,0},
			{0,0,0,0,6,0},
			{0,0,5,3,0,0},
			{0,0,0,3,0,0},
			{0,0,0,3,6,0},
			{0,1,5,0,0,2}, //Trasera
			{0,1,0,0,0,2},
			{0,1,0,0,6,2},
			{0,0,5,0,0,2},
			{0,0,0,0,0,2},
			{0,0,0,0,6,2},
			{0,0,5,3,0,2},
			{0,0,0,3,0,2},
			{0,0,0,3,6,2}	
		};
		parts.insert({'F', vector<int>{0,1,2,3,4,5,6,7,8} });
		parts.insert({'B', vector<int>{19,18,17,22,21,20,25,24,23}});
		parts.insert({'L', vector<int>{17,9,0,20,12,3,23,14,6}});
		parts.insert({'R', vector<int>{2,11,19,5,13,22,8,16,25}});
		parts.insert({'U', vector<int>{17,18,19,9,10,11,0,1,2}});
		parts.insert({'D', vector<int>{6,7,8,14,15,16,23,24,25}});
		
		parts.insert({'Z', vector<int>{0,1,2,11,19,18,17,9,10}});
		parts.insert({'X', vector<int>{3,5,4,13,22,21,20,12}});
		parts.insert({'C', vector<int>{6,7,8,16,25,24,23,14,15}});
		
		
		parts.insert({'H', vector<int>{0,1,2,11,19,18,17,9}});
		parts.insert({'J', vector<int>{3,5,22,20}});
		parts.insert({'K', vector<int>{6,7,8,16,25,24,23,14}});

		vector<glm::vec3> cubeColor;
		for(int i=0;i<26;i++){
			for (int j = 0; j < 6; j++) {
				cubeColor.push_back(colors[assignColor[i][j]]);
			}
			cubitos.push_back(Cubito(dim,cubePositions[i],cubeColor));
			cubeColor.clear();
		}

		genBuffers();
		load_create_texture();
	}
	void draw();
	void updateCurrentPart(char);
	void updateParts(char);
	void fillShuffle(char);
	void move(char);
	void deleteBuffers();
	
	void solve(vector<string> sol);
	void setSolve();
	
	void trans(char);
	void posicionarCaras();
	void juntarCaras();
	void RotarCubo();
	void explosion();
	void implosion();
private:
	void genBuffers();
	void load_create_texture();
	
};
/*
void Cubito::trans()
{
	glm::mat4 tran = glm::mat4(1.0f);
	tran = glm::translate(tran, glm::vec3(0.0f, -0.5f, 0.0f)); // x y z
	for (int k = 0; k < vertices.size(); k++)
	{
		vertex = glm::vec4(vertices[k].x, vertices[k].y, vertices[k].z, 1.0f);

		
		vertex = glm::translate(scaleMatrix, glm::vec3(1.0f + growth, 1.0f + growth, 1.0f + growth)) * vertex;

		vertices[k].x = vertex.x;
		vertices[k].y = vertex.y;
		vertices[k].z = vertex.z;
	}
	updateBuffers();
}*/

void Cubito::genBuffers() {
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);

	glBindVertexArray(VAO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * 8 * sizeof(float), &vertices[0], GL_STATIC_DRAW);
	//vertex position
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// color attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	// texture coord attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	return;
}

void Cubito::load_create_texture(Shader* ourShader) {
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture); // all upcoming GL_TEXTURE_2D operations now have effect on this texture object
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	stbi_set_flip_vertically_on_load(false);

	int width, height, nrChannels;
	// The FileSystem::getPath(...) is part of the GitHub repository so we can find files on any IDE/platform; replace it with your own image path.
	unsigned char* data = stbi_load("C://texture//allspark.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	ourShader->use();
	ourShader->setInt("texture1", 0);
	
	return;
}

void Cubito::updateBuffers() {
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * 8 * sizeof(float), &vertices[0], GL_STATIC_DRAW);

	return;
}

void Cubito::draw(Shader* ourShader, glm::vec3 pivot = glm::vec3(0.0f, 0.0f, 0.0f)) {

	glm::mat4 model = glm::mat4(1.0f);
	model = glm::translate(model, center);
	ourShader->setMat4("model", model);

	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glDrawArrays(GL_TRIANGLES, 0, 36);

	return;
}

void Cubito::move_vertices(glm::vec3 pivot, float degrees) {
	glm::vec4 vertex;
	glm::mat4 rotMatrix = glm::mat4(1.0f);
	for (int i = 0; i < vertices.size(); i++) // aplico el cambio para la rotacion en los vertices
	{
		vertex = glm::vec4(vertices[i].x, vertices[i].y, vertices[i].z, 1.0f);

		vertex = glm::rotate(rotMatrix, glm::radians(degrees), pivot) * vertex;

		vertices[i].x = vertex.x;
		vertices[i].y = vertex.y;
		vertices[i].z = vertex.z;
	}
	updateBuffers();

	return;
}


void Cubito::trans_vertices(glm::vec3 pivot) {
	glm::vec4 vertex;
	glm::mat4 rotMatrix = glm::mat4(1.0f);
	for (int i = 0; i < vertices.size(); i++) // aplico el cambio para la rotacion en los vertices
	{
		vertex = glm::vec4(vertices[i].x, vertices[i].y, vertices[i].z, 1.0f);

		vertex = glm::translate(rotMatrix, pivot) * vertex;

		vertices[i].x = vertex.x;
		vertices[i].y = vertex.y;
		vertices[i].z = vertex.z;
	}
	updateBuffers();

	return;
}

void Cubito::move(glm::vec3 pivot, Shader* ourShader, float degrees) {

	glm::mat4 model = glm::mat4(1.0f);

	//Rotamos los centros
	glm::mat4 rot = glm::mat4(1.0f);
	rot = glm::rotate(rot, glm::radians(degrees), pivot);
	glm::vec4 r = rot * glm::vec4(center, 1.0f);
	center = r;

	model = glm::translate(model, center);
	move_vertices(pivot, degrees);
	ourShader->setMat4("model", model);


	glDrawArrays(GL_TRIANGLES, 0, 36);

	return;
}

void Cubito::trans(glm::vec3 pivot, Shader* ourShader) {

	glm::mat4 model = glm::mat4(1.0f);

	//Trasladamos los centros 	LO COMENTO PORQUE AFECTA EL GIRO DEL CUBO
	/*glm::mat4 tras = glm::mat4(1.0f);
	tras = glm::translate(tras, pivot);
	glm::vec4 r = tras * glm::vec4(center, 1.0f);
	center = r;*/

	model = glm::translate(model, center);
	trans_vertices(pivot);
	ourShader->setMat4("model", model);


	glDrawArrays(GL_TRIANGLES, 0, 36);

	return;
}



void Cubito::deleteBuffers() {
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);

	return;
}


void Rubik::genBuffers() {
	for (int i = 0; i < cubitos.size(); i++){
		cubitos[i].genBuffers();
	}

	return;
}

void Rubik::load_create_texture() {
	for (int i = 0; i < cubitos.size(); i++) {
		cubitos[i].load_create_texture(shader);
	}
	
	return;
}

void Rubik::draw() {			
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	for (int i = 0; i < cubitos.size(); i++)
	{
		cubitos[i].draw(shader);
	}
	glfwSwapBuffers(window);
	glfwPollEvents();

	return;
}

void Rubik::updateCurrentPart(char p) {             //Actualizamos las posiciones de los cubitos de la capa actual
	vector<int>* pv = &(parts.find(p)->second); // actualiza la cara que acaba de moverse
	vector<int> temp = (*pv);

	for (int i = 0; i < 3; i++) { // 0 1 2 - 3 4 5 - 6 7 8 
		(*pv)[i] = temp[6 - (i * 3)];                  //0,1,2
		(*pv)[i + 3] = temp[10 - ((i + 1) * 3)];     //3,4,5
		(*pv)[i + 6] = temp[i + 12 - ((i + 1) * 4)];   //6,7,8
	}

	return;
}

void Rubik::updateParts(char movedChoosen) {  //Sides
	vector<int>* pMoved = &(parts.find(movedChoosen)->second);         //Side moved
	vector<char> updateSides;   //Sides to update R,D,L,U,F,B
	vector<vector<int>> updateIndex; //Index to update divided in parts of a side
	switch (movedChoosen)
	{
	case 'F':
		updateSides = vector<char>{ 'U','R','D','L' };
		updateIndex = vector<vector<int>>{ {6,7,8}, {0,3,6}, {0,1,2}, {2,5,8} }; // indices de cada cara, hay 9
		break;
	case 'B':
		updateSides = vector<char>{ 'U','L','D','R' };       //Actualizar desde B
		updateIndex = vector<vector<int>>{ {2,1,0}, {0,3,6}, {8,7,6}, {2,5,8} };
		break;
	case 'L':
		updateSides = vector<char>{ 'U','F','D','B' };
		updateIndex = vector<vector<int>>{ {0,3,6}, {0,3,6}, {6,3,0}, {2,5,8} };
		break;
	case 'R':
		updateSides = vector<char>{ 'U','B','D','F' };
		updateIndex = vector<vector<int>>{ {8,5,2}, {0,3,6}, {2,5,8}, {2,5,8} };
		break;
	case 'D':
		updateSides = vector<char>{ 'F','R','B','L' };
		updateIndex = vector<vector<int>>{ {6,7,8}, {6,7,8}, {8,7,6}, {8,7,6} };
		break;
	case 'U':
		updateSides = vector<char>{ 'B','R','F','L' };
		updateIndex = vector<vector<int>>{ {2,1,0}, {2,1,0}, {0,1,2}, {0,1,2} };
		break;
	default:
		break;
	}
	updateCurrentPart(movedChoosen); // se actualiza la cara que se movio
	vector<vector<int>> sortedIndex = { {0,1,2},{2,5,8},{6,7,8},{0,3,6} }; //Orden de los indices que actualizaremos U R D L
	vector<int>* side_updating;          //Side updating
	for (int i = 0; i < 4; i++) { // actualizo los lados que fueron afectados
		side_updating = &(parts.find(updateSides[i])->second); // U R D L 
		for (int j = 0; j < 3; j++) {
			(*side_updating)[updateIndex[i][j]] = (*pMoved)[sortedIndex[i][j]];
		}
	}

	return;
}

void Rubik::fillShuffle(char sideMove) { // guarda los movimientos para el solver
	if (degrees == -1) { // guarda los movimiendos normales
		shuffle.push_back(string(1, sideMove));
		cout << sideMove << " ";
	}
	else { // guarda movimientos prima
		string s(1, sideMove);
		s.push_back('\'');
		shuffle.push_back(s);
		cout << s << " ";
	}
	
	return;
}

void Rubik::move(char sideMove) {
	vector<int>* pv = &(parts.find(sideMove)->second);
	for (int k = 0; k < 90; k++) { // 90 grados
		for (int j = 0; j < pv->size(); j++) { // size 9 roto los 9 cubos 1 grado 90 veces
			cubitos[(*pv)[j]].move(cubitos[(*pv)[4]].center, shader, degrees);      //[4] es el pivot
		}
		draw(); // dibuja la animacion, en vez de hacer el giro de golpe
	}

	return;
}

void Rubik::trans(char sideMove) {
	
	if(sideMove=='H' || sideMove=='J' || sideMove=='K')
	{	
		vector<int>* pv = &(parts.find(sideMove)->second); // Z = 0 1 2
		
		for(int i = 0;i<pv->size();i++) // numero de veces que se va a subir
		{
			for (int k = 0; k < 500; k++) { // 90 grados
				//for (; j < pv->size();) { // size 9 roto los 9 cubos 1 grado 90 veces
				
					
				cubitos[(*pv)[i]].trans(glm::vec3(0.0f, -0.02f ,0.0f), shader);      //[4] es el pivot
					
					draw();
				
					//cubitos[(*pv)[j]].draw(shader); // dibuja todo el cubo subiendo junto
					//cout<<"DIBUJADOS: "<<j;
				//}
				 //draw();// dibuja la animacion, en vez de hacer el giro de golpe
			}
		}
	}
	else // SUBE
	{
		vector<int>* pv = &(parts.find(sideMove)->second); // Z = 0 1 2
		
		for(int i = 0;i<pv->size();i++) // numero de veces que se va a subir
		{
			for (int k = 0; k < 500; k++) { // 90 grados
				//for (; j < pv->size();) { // size 9 roto los 9 cubos 1 grado 90 veces
				
					
				cubitos[(*pv)[i]].trans(glm::vec3(0.0f, 0.02f ,0.0f), shader);      //[4] es el pivot
					
					draw();
				
					//cubitos[(*pv)[j]].draw(shader); // dibuja todo el cubo subiendo junto
					//cout<<"DIBUJADOS: "<<j;
				//}
				 //draw();// dibuja la animacion, en vez de hacer el giro de golpe
			}
		}
	}
	return;
}

void Rubik::posicionarCaras()
{
	// mover 12 4 13 10 15 21
	vector<int> centros = {12,4,13,10,15,21};
	// Eje Y 10 15
	

		for(int i = 0;i<6;i++) // 6 centros
		{
			
			//if(centros[i]==10) cubitos[centros[i]].trans(glm::vec3(0.0f, 8.5f ,0.0f), shader);      //[4] es el pivot
			if(centros[i]==15) cubitos[centros[i]].trans(glm::vec3(0.0f, -20.0f ,0.0f), shader);      //[4] es el pivot
			if(centros[i]==12) cubitos[centros[i]].trans(glm::vec3(-10.0f, -10.0f ,0.0f), shader);      //[4] es el pivot
			if(centros[i]==13) cubitos[centros[i]].trans(glm::vec3(10.0f, -10.0f ,0.0f), shader);      //[4] es el pivot
			if(centros[i]==4) cubitos[centros[i]].trans(glm::vec3(0.0f, -10.0f ,10.0f), shader);      //[4] es el pivot
			if(centros[i]==21) cubitos[centros[i]].trans(glm::vec3(0.0f, -10.0f ,-10.0f), shader);      //[4] es el pivot
				
					
					
		}draw(); // que no se vea la animacion
	
	return;
}

void Rubik::juntarCaras()
{
	// mover 12 4 13 10 15 21
	vector<int> centros = {12,4,13,10,15,21};
	// Eje Y 10 15
	

		for(int i = 0;i<6;i++) // 6 centros
		{
			for (int k = 0; k < 500; k++) {
			if(centros[i]==10) cubitos[centros[i]].trans(glm::vec3(0.0f, -0.02f ,0.0f), shader);  draw();    //[4] es el pivot
			if(centros[i]==15) cubitos[centros[i]].trans(glm::vec3(0.0f, 0.02f ,0.0f), shader);  draw();    //[4] es el pivot
			if(centros[i]==12) cubitos[centros[i]].trans(glm::vec3(0.02f, 0.0f ,0.0f), shader);  draw();    //[4] es el pivot
			if(centros[i]==13) cubitos[centros[i]].trans(glm::vec3(-0.02f, 0.0f ,0.0f), shader);  draw();    //[4] es el pivot
			if(centros[i]==4) cubitos[centros[i]].trans(glm::vec3(0.0f, 0.0f ,-0.02f), shader);  draw();    //[4] es el pivot
			if(centros[i]==21) cubitos[centros[i]].trans(glm::vec3(0.0f, 0.0f ,0.02f), shader);  draw();    //[4] es el pivot
				
			}	
					
		}//draw(); // que no se vea la animacion
	
	return;
}

void Rubik::RotarCubo()
{
	vector<int> pv = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25};
	
	for (int k = 0; k < 7200; k++) { // 90 grados
		for (int j = 0; j < pv.size(); j++) { // size 9 roto los 9 cubos 1 grado 90 veces
			cubitos[pv[j]].move(cubitos[pv[10]].center, shader, degrees);      //[4] es el pivot
		}
		draw(); // dibuja la animacion, en vez de hacer el giro de golpe
	}

	return;
}

void Rubik::explosion()
{
	vector<int> pv = {0,2,6,8,17,19,23,25,1,9,11,18,7,14,16,24,3,4,5,12,13,20,21,22,10,15};
	
	for (int k = 0; k < 500; k++) { // 90 grados
		for (int j = 0; j < pv.size(); j++) { // size 9 roto los 9 cubos 1 grado 90 veces
		if(pv[j]==0) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.02f ,0.02f), shader);      //ESQUINAS
		else if(pv[j]==2) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.02f ,0.02f), shader);
		else if(pv[j]==6) cubitos[pv[j]].trans(glm::vec3(-0.02f, -0.02f ,0.02f), shader);
		else if(pv[j]==8) cubitos[pv[j]].trans(glm::vec3(0.02f, -0.02f ,0.02f), shader);
		else if(pv[j]==17) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.02f ,-0.02f), shader);
		else if(pv[j]==19) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.02f ,-0.02f), shader);
		else if(pv[j]==23) cubitos[pv[j]].trans(glm::vec3(-0.02f, -0.02f ,-0.02f), shader);
		else if(pv[j]==25) cubitos[pv[j]].trans(glm::vec3(0.02f, -0.02f ,-0.02f), shader);
		// CENTROS
		else if(pv[j]==1) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.02f ,0.02f), shader);
		else if(pv[j]==9) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.02f ,0.0f), shader);
		else if(pv[j]==11) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.02f ,0.0f), shader);
		else if(pv[j]==18) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.02f ,-0.02f), shader);
		else if(pv[j]==7) cubitos[pv[j]].trans(glm::vec3(0.0f, -0.02f ,0.02f), shader);
		else if(pv[j]==14) cubitos[pv[j]].trans(glm::vec3(-0.02f, -0.02f ,0.0f), shader);
		else if(pv[j]==16) cubitos[pv[j]].trans(glm::vec3(0.02f, -0.02f ,0.0f), shader);
		else if(pv[j]==24) cubitos[pv[j]].trans(glm::vec3(0.0f, -0.02f ,-0.02f), shader);
		
		// MEDIO
		else if(pv[j]==3) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.0f ,0.02f), shader);
		else if(pv[j]==4) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.0f ,0.02f), shader);
		else if(pv[j]==5) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.0f ,0.02f), shader);
		else if(pv[j]==12) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.0f ,0.0f), shader);
		else if(pv[j]==13) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.0f ,0.0f), shader);
		else if(pv[j]==20) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.0f ,-0.02f), shader);
		else if(pv[j]==21) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.0f ,-0.02f), shader);
		else if(pv[j]==22) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.0f ,-0.02f), shader);
		
		// CABEZA Y PIE
		else if(pv[j]==10) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.02f ,0.0f), shader);
		else if(pv[j]==15) cubitos[pv[j]].trans(glm::vec3(0.0f, -0.02f ,0.0f), shader);
		
		}
		draw(); // dibuja la animacion, en vez de hacer el giro de golpe
	}

	return;
}

void Rubik::implosion()
{
	vector<int> pv = {0,2,6,8,17,19,23,25,1,9,11,18,7,14,16,24,3,4,5,12,13,20,21,22,10,15};
	
	for (int k = 0; k < 500; k++) { // 90 grados
		for (int j = 0; j < pv.size(); j++) { // size 9 roto los 9 cubos 1 grado 90 veces
		if(pv[j]==0) cubitos[pv[j]].trans(glm::vec3(0.02f, -0.02f ,-0.02f), shader);      //ESQUINAS
		else if(pv[j]==2) cubitos[pv[j]].trans(glm::vec3(-0.02f, -0.02f ,-0.02f), shader);
		else if(pv[j]==6) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.02f ,-0.02f), shader);
		else if(pv[j]==8) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.02f ,-0.02f), shader);
		else if(pv[j]==17) cubitos[pv[j]].trans(glm::vec3(0.02f, -0.02f ,0.02f), shader);
		else if(pv[j]==19) cubitos[pv[j]].trans(glm::vec3(-0.02f, -0.02f ,0.02f), shader);
		else if(pv[j]==23) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.02f ,0.02f), shader);
		else if(pv[j]==25) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.02f ,0.02f), shader);
		// CENTROS
		else if(pv[j]==1) cubitos[pv[j]].trans(glm::vec3(0.0f, -0.02f ,-0.02f), shader);
		else if(pv[j]==9) cubitos[pv[j]].trans(glm::vec3(0.02f, -0.02f ,0.0f), shader);
		else if(pv[j]==11) cubitos[pv[j]].trans(glm::vec3(-0.02f, -0.02f ,0.0f), shader);
		else if(pv[j]==18) cubitos[pv[j]].trans(glm::vec3(0.0f, -0.02f ,0.02f), shader);
		else if(pv[j]==7) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.02f ,-0.02f), shader);
		else if(pv[j]==14) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.02f ,0.0f), shader);
		else if(pv[j]==16) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.02f ,0.0f), shader);
		else if(pv[j]==24) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.02f ,0.02f), shader);
		
		// MEDIO
		else if(pv[j]==3) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.0f ,-0.02f), shader);
		else if(pv[j]==4) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.0f ,-0.02f), shader);
		else if(pv[j]==5) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.0f ,-0.02f), shader);
		else if(pv[j]==12) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.0f ,0.0f), shader);
		else if(pv[j]==13) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.0f ,0.0f), shader);
		else if(pv[j]==20) cubitos[pv[j]].trans(glm::vec3(0.02f, 0.0f ,0.02f), shader);
		else if(pv[j]==21) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.0f ,0.02f), shader);
		else if(pv[j]==22) cubitos[pv[j]].trans(glm::vec3(-0.02f, 0.0f ,0.02f), shader);
		
		// CABEZA Y PIE
		else if(pv[j]==10) cubitos[pv[j]].trans(glm::vec3(0.0f, -0.02f ,0.0f), shader);
		else if(pv[j]==15) cubitos[pv[j]].trans(glm::vec3(0.0f, 0.02f ,0.0f), shader);
		
		}
		draw(); // dibuja la animacion, en vez de hacer el giro de golpe
	}

	return;
}
// SOLVER

void Rubik::solve(vector<string> sol) {
	solution = sol;
	char sideMoved;
	degrees = -1.0f;
	for (int i = 0; i < solution.size(); i++) {
		if (i > 1) {
			std::cout << "\nSOLUTION: ";
			for (int j = i; j < solution.size(); j++) std::cout << solution[j] << " ";
		}
		if (solution[i].size() == 1) {
			sideMoved = solution[i].c_str()[0];
			move(sideMoved);
			updateParts(sideMoved);
		}
		else if (solution[i].size() == 2) {
			if (solution[i][1] == '\'') {
				degrees = 1.0f;
				sideMoved = solution[i].c_str()[0];
				move(sideMoved);
				updateParts(sideMoved);
				updateParts(sideMoved);
				updateParts(sideMoved);
				degrees = -1.0f;
			}
			else {
				sideMoved = solution[i].c_str()[0];
				move(sideMoved);
				updateParts(sideMoved);
				move(sideMoved);
				updateParts(sideMoved);
			}
		}
	}
	std::cout << "\n\nSHUFFLE: ";

	return;
}

void Rubik::setSolve() {
	vector<string> move = get_solution(to_cube_not(shuffle));
	cout << "\nSOLUTION: ";
	for (int i = 0; i < move.size(); i++) cout << move[i] << " ";
	solve(move);
	shuffle.clear();
	"\nSHUFFLE: ";

	return;
}


void Rubik::deleteBuffers() {
	for (int i = 0; i < cubitos.size(); i++)
	{
		cubitos[i].deleteBuffers();
	}

	return;
}
/*
void Rubik::EmpezarAnimacion(){
	// subir U
	char sideMove = 'U';
	vector<int>* pv = &(parts.find(sideMove)->second); // 0 1 2 9 10 11 17 18 19
	for (int k = 0; k < 90; k++) { // 90 grados
		for (int j = 0; j < pv->size(); j++) { // size 9 roto los 9 cubos 1 grado 90 veces
			cubitos[(*pv)[j]].trans(cubitos[(*pv)[4]].center, shader, degrees);      //[4] es el pivot
		}
		draw(); // dibuja la animacion, en vez de hacer el giro de golpe
	}

	return;
}*/



//// CAMARA

class Camera {
public:
	glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
	glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
	glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

	bool firstMouse = true;
	float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
	float pitch = 0.0f;
	float lastX = 800.0f / 2.0;
	float lastY = 600.0 / 2.0;
	float fov = 45.0f;

	// timing
	float deltaTime = 0.0f;	// time between current frame and last frame
	float lastFrame = 0.0f;
	
	void updateFrame();
};

void Camera::updateFrame() {
	float currentFrame = static_cast<float>(glfwGetTime());
	deltaTime = currentFrame - lastFrame;
	lastFrame = currentFrame;
}

//// IMPLEMENTACION


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

//_______--------------------------------------

Camera cam;
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

char sideMove;
bool isMoving = false;
bool changeDirection = false;
bool solving = false;
bool animacion = false;
//----------------------------------------


void init() {
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif
    return;
}

GLFWwindow* createWindow(const char* title) {
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, title, NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window, key_callback);
    
    return window;
}

bool glad(){
   if (!gladLoadGL(glfwGetProcAddress))
   {
       std::cout << "Failed to initialize GLAD" << std::endl;
       return -1;
   }
    return 1;
}


//TEXTURE
void load_create_texture(unsigned int &texture, const char* title, bool flip=0) {
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture); // all upcoming GL_TEXTURE_2D operations now have effect on this texture object
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

void menu() {
    cout << "\t\tWELCOME TO RUBIK CUBE\n";
    cout << "Keys to move:" << "\n\t - MOUSE -> CAMERA" << "\n\t - UP arrow -> UP(U)"<< "\n\t - DOWN arrow -> DOWN(D)";
    cout << "\n\t - LEFT arrow -> LEFT(L)" << "\n\t - RIGHT arrow -> RIGHT(R)";
    cout << "\n\t - F -> FRONT(F)" << "\n\t - B -> BACK(B)"<< "\n\t - (Right) SHIFT -> CHANGE TO CLOCKWISE OR TO ANTICLOCKWISE";
    cout << "\n\nSHUFFLE: ";

    return;
}

int main() {
    init();
    GLFWwindow* window = createWindow("Cubo Rubik");
    if (window == NULL || !glad()) return -1;  //return -1

    //Camera
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glEnable(GL_DEPTH_TEST);
    Shader ourShader("shader.vs", "shader.fs");

    menu();

    Rubik rubik(window, &ourShader, 0.2f);


    while (!glfwWindowShouldClose(window))
    {
        cam.updateFrame();
        glClearColor(0.67f, 0.86f, 0.78f, 1.0f);
        ourShader.use();

        glm::mat4 projection = glm::perspective(glm::radians(cam.fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        ourShader.setMat4("projection", projection);

        glm::mat4 view = glm::lookAt(cam.cameraPos, glm::vec3(0.0f, 0.0f, 0.0f), cam.cameraUp);
        ourShader.setMat4("view", view);

        
		if (solving == true) {
            Rubik* rubikMoving = &rubik;
            rubikMoving->setSolve();
            
            solving = false;
        }
        else if (isMoving == false && changeDirection) {
            changeDirection = false;
            rubik.degrees *= -1; // cambia direccion
        }

        else if (isMoving == true) {
            Rubik* rubikMoving = &rubik;
            Rubik* rubikStatic = nullptr;
            rubikMoving->fillShuffle(sideMove); // guardo los movimientos
            rubikMoving->move(sideMove); // muevo una camada 90 grados
            isMoving = false; 
            for (int i = 0; rubikMoving->degrees == 1.0f && i < 2; i++) { // actualizo las camadas
                rubikMoving->updateParts(sideMove); // si se giro en antihorario, actualizo 2 veces
				
			} // antihorario: actualizo 2 veces y luego una tercera vez
            rubikMoving->updateParts(sideMove);
        }
		else if (animacion == true)
		{
			Rubik* rubikMoving = &rubik;
            rubikMoving->trans(sideMove); //Z
			rubikMoving->trans('X');
			rubikMoving->trans('C');
			std::this_thread::sleep_for(std::chrono::seconds(2));
			// BAJA el cubo
			rubikMoving->trans('K');
			rubikMoving->trans('J');
			rubikMoving->trans('H');
			rubikMoving->posicionarCaras();
			rubikMoving->juntarCaras();
			rubikMoving->RotarCubo();
			rubikMoving->explosion();
			std::this_thread::sleep_for(std::chrono::seconds(3));
			rubikMoving->implosion();
			animacion = false;
		}
        else {
            rubik.draw();
        }

    }
    rubik.deleteBuffers();
    glfwTerminate();
	
	return 0;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float cameraSpeed = 0.2;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cam.cameraPos += cameraSpeed * cam.cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cam.cameraPos -= cameraSpeed * cam.cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cam.cameraPos -= glm::normalize(glm::cross(cam.cameraFront, cam.cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cam.cameraPos += glm::normalize(glm::cross(cam.cameraFront, cam.cameraUp)) * cameraSpeed;
    if (!isMoving) {
        if (glfwGetKey(window, GLFW_KEY_RIGHT_SHIFT) == GLFW_PRESS) {
            changeDirection = true;
        }
        if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
            isMoving = true;
            sideMove = 'U';
        }
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
            isMoving = true;
            sideMove = 'L';
        }
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
            isMoving = true;
            sideMove = 'R';
        }
        if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
            isMoving = true;
            sideMove = 'D';
        }
        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            isMoving = true;
            sideMove = 'F';
        }
        if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS) {
            isMoving = true;
            sideMove = 'B';
        }// SOLVER
		if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
            solving = true;
        }
		//ANIMACION
		if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
            animacion = true;
			sideMove = 'Z';
        }
		if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
            animacion = true;
			sideMove = 'X';
        }
		if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS) {
            animacion = true;
			sideMove = 'C';
        }
    }

}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}



void mouse_callback(GLFWwindow* window, double xposIn, double yposIn)
{
    float xpos = static_cast<float>(xposIn);
    float ypos = static_cast<float>(yposIn);

    if (cam.firstMouse)
    {
        cam.lastX = xpos;
        cam.lastY = ypos;
        cam.firstMouse = false;
    }

    float xoffset = xpos - cam.lastX;
    float yoffset = cam.lastY - ypos; // reversed since y-coordinates go from bottom to top
    cam.lastX = xpos;
    cam.lastY = ypos;

    float sensitivity = 0.1f; // change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;


    if (xoffset > 0 && cam.cameraPos.x < 5) cam.cameraPos.x += xoffset;
    else if (xoffset < 0 && cam.cameraPos.x > -5) cam.cameraPos.x += xoffset;

    if (yoffset > 0 && cam.cameraPos.y < 5) cam.cameraPos.y += yoffset;
    else if (yoffset < 0 && cam.cameraPos.y > -5) cam.cameraPos.y += yoffset;

    cam.yaw += xoffset;
    cam.pitch += yoffset;

    if (cam.pitch > 89.0f)
        cam.pitch = 89.0f;
    if (cam.pitch < -89.0f)
        cam.pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(cam.yaw)) * cos(glm::radians(cam.pitch));
    front.y = sin(glm::radians(cam.pitch));
    front.z = sin(glm::radians(cam.yaw)) * cos(glm::radians(cam.pitch));
    cam.cameraFront = glm::normalize(front);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    cam.fov -= (float)yoffset;
    if (cam.fov < 1.0f)
        cam.fov = 1.0f;
    if (cam.fov > 45.0f)
        cam.fov = 45.0f;
}